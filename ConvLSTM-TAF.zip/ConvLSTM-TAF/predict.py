import os
import torch
import numpy as np
import rasterio
from tqdm import tqdm
import matplotlib.pyplot as plt
import pandas as pd
from scipy.ndimage import binary_closing, binary_opening, binary_dilation
from skimage.morphology import remove_small_objects, remove_small_holes
from typing import Dict, Tuple

# Font settings
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 150


class PredictConfig:
    # Data paths
    ROOT_DIR = r"\data"
    IMAGES_DIR = r"\data\images"
    RAIN_CSV = r"\data\GPM\avg_precip_timeseries.csv"
    DEM_PATH = r"\data\dem\DEM.tif"

    # Model path
    MODEL_DIR = r"\model"

    # === Change model here ===
    MODEL_NAME = "model_name"  # Options: convlstm_only, convlstm_dem, convlstm_rain, full_model

    # Output path
    OUT_DIR = r"\results"

    # Model parameters
    PATCH_SIZE = 256
    HIDDEN_DIM = 32
    RAIN_DIM = 16

    # Prediction parameters
    SEQ_IN = 5
    PREDICT_START = 816
    PREDICT_END = 824

    # Threshold
    THRESHOLD = 0.3
    USE_ADAPTIVE_THRESHOLD = True
    THRESHOLDS = {
        'very_high_rain': 0.15,
        'high_rain': 0.20,
        'medium_rain': 0.25,
        'low_rain': 0.30
    }

    # Post-processing
    MIN_OBJECT_SIZE = 100
    HOLE_SIZE = 100


from models import get_model, ABLATION_MODELS, count_parameters


def setup_directories(config):
    os.makedirs(config.OUT_DIR, exist_ok=True)
    for subdir in ["tifs", "pngs", "pngs/gt", "pngs/prob", "pngs/pred",
                   "pngs/diff", "pngs/ndwi", "pngs/combined", "pngs/analysis"]:
        os.makedirs(os.path.join(config.OUT_DIR, subdir), exist_ok=True)


def load_model(config, device):
    model_path = os.path.join(config.MODEL_DIR, config.MODEL_NAME, "best_model.pth")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model not found: {model_path}")

    print(f"\nLoading model: {config.MODEL_NAME}")
    model = get_model(config.MODEL_NAME, input_channels=1, hidden_dim=config.HIDDEN_DIM,
                      patch_size=config.PATCH_SIZE, dem_channels=1, rain_dim=config.RAIN_DIM).to(device)

    checkpoint = torch.load(model_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()

    print(f"Model loaded: {count_parameters(model):,} parameters")
    return model


def load_rain_data(config):
    rain_df = pd.read_csv(config.RAIN_CSV)
    rain_dict = {str(int(row["Date"])): float(row["Avg_Precip_mm_per_day"]) for _, row in rain_df.iterrows()}
    print(f"Rainfall data: {len(rain_dict)} records")
    return rain_dict


def load_dem(config):
    with rasterio.open(config.DEM_PATH) as src:
        dem_full = src.read().astype(np.float32)
        profile = src.profile.copy()
        profile.update({"count": 1, "dtype": "float32", "compress": "lzw"})
        dem_full = (dem_full - dem_full.mean()) / (dem_full.std() + 1e-8)
    return dem_full, profile


def load_ndwi(path):
    with rasterio.open(path) as src:
        arr = src.read(1).astype(np.float32)
        arr = np.nan_to_num(arr, nan=0.0)
        arr = np.clip(arr, -1, 1)
    return arr


def load_all_ndwi(config):
    ndwi_cache = {}
    for fname in os.listdir(config.IMAGES_DIR):
        if fname.endswith('.tif'):
            date = fname.replace('.tif', '')
            ndwi_cache[date] = load_ndwi(os.path.join(config.IMAGES_DIR, fname))
            print(f"  {date}: [{ndwi_cache[date].min():.3f}, {ndwi_cache[date].max():.3f}]")
    return ndwi_cache


def select_threshold(rain_future, config):
    if not config.USE_ADAPTIVE_THRESHOLD:
        return config.THRESHOLD
    if rain_future > 150:
        return config.THRESHOLDS['very_high_rain']
    elif rain_future > 50:
        return config.THRESHOLDS['high_rain']
    elif rain_future > 20:
        return config.THRESHOLDS['medium_rain']
    return config.THRESHOLDS['low_rain']


def predict_full_image(model, ndwi_seq_full, rain_past, rain_future, dem_full, device, patch_size=256):
    T, H, W = ndwi_seq_full.shape
    pred_full = np.zeros((H, W), dtype=np.float32)
    n_rows = (H + patch_size - 1) // patch_size
    n_cols = (W + patch_size - 1) // patch_size

    for row in range(n_rows):
        for col in range(n_cols):
            i_start, j_start = row * patch_size, col * patch_size
            i_end, j_end = min(i_start + patch_size, H), min(j_start + patch_size, W)
            actual_h, actual_w = i_end - i_start, j_end - j_start

            ndwi_patch = ndwi_seq_full[:, i_start:i_end, j_start:j_end]
            dem_patch = dem_full[:, i_start:i_end, j_start:j_end]

            if actual_h < patch_size or actual_w < patch_size:
                ndwi_padded = np.zeros((T, patch_size, patch_size), dtype=np.float32)
                dem_padded = np.zeros((dem_full.shape[0], patch_size, patch_size), dtype=np.float32)
                ndwi_padded[:, :actual_h, :actual_w] = ndwi_patch
                dem_padded[:, :actual_h, :actual_w] = dem_patch
                ndwi_patch, dem_patch = ndwi_padded, dem_padded

            ndwi_tensor = torch.tensor(ndwi_patch).unsqueeze(0).unsqueeze(2).float().to(device)
            rain_past_t = torch.tensor([[rain_past]]).float().to(device)
            rain_future_t = torch.tensor([[rain_future]]).float().to(device)
            dem_tensor = torch.tensor(dem_patch).unsqueeze(0).float().to(device)

            with torch.no_grad():
                output = model(ndwi_tensor, rain_past_t, rain_future_t, dem_tensor)
                pred = torch.sigmoid(output).squeeze().cpu().numpy()

            pred_full[i_start:i_end, j_start:j_end] = pred[:actual_h, :actual_w]

    return pred_full


def apply_postprocessing(pred_binary, config):
    pred_closed = binary_closing(pred_binary, structure=np.ones((3, 3)))
    pred_opened = binary_opening(pred_closed, structure=np.ones((2, 2)))
    pred_cleaned = remove_small_objects(pred_opened.astype(bool), min_size=config.MIN_OBJECT_SIZE)
    pred_final = remove_small_holes(pred_cleaned, area_threshold=config.HOLE_SIZE)
    return pred_final.astype(np.float32)


def calculate_ssim(img1, img2):
    """Calculate SSIM between two images"""
    from scipy.ndimage import uniform_filter
    C1, C2 = 0.01 ** 2, 0.03 ** 2
    img1, img2 = img1.astype(np.float64), img2.astype(np.float64)
    mu1, mu2 = uniform_filter(img1, size=11), uniform_filter(img2, size=11)
    sigma1_sq = uniform_filter(img1 ** 2, size=11) - mu1 ** 2
    sigma2_sq = uniform_filter(img2 ** 2, size=11) - mu2 ** 2
    sigma12 = uniform_filter(img1 * img2, size=11) - mu1 * mu2
    ssim_map = ((2 * mu1 * mu2 + C1) * (2 * sigma12 + C2)) / ((mu1 ** 2 + mu2 ** 2 + C1) * (sigma1_sq + sigma2_sq + C2))
    return float(ssim_map.mean())


def evaluate_prediction(pred_binary, pred_prob, gt_ndwi, water_threshold=0.1):
    """Evaluate prediction results"""
    gt_binary = (gt_ndwi > water_threshold).astype(np.float32)

    # Confusion matrix
    tp = ((pred_binary == 1) & (gt_binary == 1)).sum()
    fp = ((pred_binary == 1) & (gt_binary == 0)).sum()
    fn = ((pred_binary == 0) & (gt_binary == 1)).sum()
    tn = ((pred_binary == 0) & (gt_binary == 0)).sum()

    eps = 1e-7
    precision = tp / max(tp + fp, eps)
    recall = tp / max(tp + fn, eps)
    f1 = 2 * precision * recall / max(precision + recall, eps)
    iou = tp / max(tp + fp + fn, eps)
    accuracy = (tp + tn) / (tp + fp + fn + tn)

    # Image similarity metrics (binary vs binary)
    ssim = calculate_ssim(pred_binary, gt_binary)
    rmse = np.sqrt(np.mean((pred_binary - gt_binary) ** 2))
    mae = np.mean(np.abs(pred_binary - gt_binary))

    # Kappa coefficient
    total = tp + fp + fn + tn
    po = (tp + tn) / total
    pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / (total ** 2)
    kappa = (po - pe) / max(1 - pe, eps)

    return {
        'accuracy': accuracy, 'precision': precision, 'recall': recall,
        'f1': f1, 'iou': iou, 'kappa': kappa,
        'tp': int(tp), 'fp': int(fp), 'fn': int(fn), 'tn': int(tn),
        'ssim': ssim, 'rmse': rmse, 'mae': mae,
        'gt_water_ratio': gt_binary.mean(), 'pred_water_ratio': pred_binary.mean()
    }


def save_separate_figures(pred_prob, pred_binary, gt_ndwi, metrics, target_date, out_dir, has_gt=True):
    """Save each figure separately"""

    # Probability map
    fig, ax = plt.subplots(figsize=(10, 10))
    im = ax.imshow(pred_prob, cmap='Blues', vmin=0, vmax=1)
    ax.set_title(f'Prediction Probability - {target_date}', fontsize=14)
    ax.axis('off')
    plt.colorbar(im, ax=ax, fraction=0.046)
    plt.savefig(os.path.join(out_dir, "pngs/prob", f"{target_date}_prob.png"), dpi=150, bbox_inches='tight')
    plt.close()

    # Binary prediction map
    fig, ax = plt.subplots(figsize=(10, 10))
    ax.imshow(pred_binary, cmap='Blues', vmin=0, vmax=1)
    ax.set_title(f'Prediction - {target_date}\nWater: {pred_binary.mean():.2%}', fontsize=14)
    ax.axis('off')
    plt.savefig(os.path.join(out_dir, "pngs/pred", f"{target_date}_pred.png"), dpi=150, bbox_inches='tight')
    plt.close()

    if has_gt and gt_ndwi is not None:
        gt_binary = (gt_ndwi > 0.1).astype(np.float32)

        # Ground Truth
        fig, ax = plt.subplots(figsize=(10, 10))
        ax.imshow(gt_binary, cmap='Blues', vmin=0, vmax=1)
        ax.set_title(f'Ground Truth - {target_date}\nWater: {gt_binary.mean():.2%}', fontsize=14)
        ax.axis('off')
        plt.savefig(os.path.join(out_dir, "pngs/gt", f"{target_date}_gt.png"), dpi=150, bbox_inches='tight')
        plt.close()

        # NDWI
        fig, ax = plt.subplots(figsize=(10, 10))
        im = ax.imshow(gt_ndwi, cmap='RdYlBu', vmin=-0.5, vmax=0.5)
        ax.set_title(f'NDWI - {target_date}', fontsize=14)
        ax.axis('off')
        plt.colorbar(im, ax=ax, fraction=0.046)
        plt.savefig(os.path.join(out_dir, "pngs/ndwi", f"{target_date}_ndwi.png"), dpi=150, bbox_inches='tight')
        plt.close()

        # Difference map
        fig, ax = plt.subplots(figsize=(10, 10))
        diff = np.zeros((*gt_binary.shape, 3))
        diff[..., 0] = (pred_binary == 1) & (gt_binary == 0)  # FP: Red
        diff[..., 1] = (pred_binary == 1) & (gt_binary == 1)  # TP: Green
        diff[..., 2] = (pred_binary == 0) & (gt_binary == 1)  # FN: Blue
        ax.imshow(diff)
        ax.set_title(f'Difference - {target_date}\nGreen=TP, Red=FP, Blue=FN', fontsize=14)
        ax.axis('off')
        plt.savefig(os.path.join(out_dir, "pngs/diff", f"{target_date}_diff.png"), dpi=150, bbox_inches='tight')
        plt.close()

        # Combined figure
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        axes[0, 0].imshow(gt_binary, cmap='Blues')
        axes[0, 0].set_title(f'GT\n{gt_binary.mean():.2%}')
        axes[0, 0].axis('off')
        im = axes[0, 1].imshow(pred_prob, cmap='Blues', vmin=0, vmax=1)
        axes[0, 1].set_title('Probability')
        axes[0, 1].axis('off')
        plt.colorbar(im, ax=axes[0, 1], fraction=0.046)
        axes[0, 2].imshow(pred_binary, cmap='Blues')
        axes[0, 2].set_title(f'Prediction\n{pred_binary.mean():.2%}')
        axes[0, 2].axis('off')
        axes[1, 0].imshow(diff)
        axes[1, 0].set_title('Difference')
        axes[1, 0].axis('off')
        im2 = axes[1, 1].imshow(gt_ndwi, cmap='RdYlBu', vmin=-0.5, vmax=0.5)
        axes[1, 1].set_title('NDWI')
        axes[1, 1].axis('off')
        plt.colorbar(im2, ax=axes[1, 1], fraction=0.046)
        axes[1, 2].axis('off')
        metrics_text = f"F1: {metrics['f1']:.4f}\nIoU: {metrics['iou']:.4f}\nSSIM: {metrics['ssim']:.4f}\nKappa: {metrics['kappa']:.4f}"
        axes[1, 2].text(0.5, 0.5, metrics_text, fontsize=16, ha='center', va='center',
                        bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))
        plt.suptitle(f'Evaluation - {target_date}', fontsize=16, fontweight='bold')
        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "pngs/combined", f"{target_date}_combined.png"), dpi=150, bbox_inches='tight')
        plt.close()


def generate_change_detection(all_predictions, ndwi_cache, out_dir):
    """Generate change detection maps with enlarged change areas"""
    from matplotlib.patches import Patch

    dates = sorted(all_predictions.keys())
    if len(dates) < 2:
        return

    print(f"\nGenerating change detection maps...")
    first_date, last_date = dates[0], dates[-1]
    first_pred, last_pred = all_predictions[first_date], all_predictions[last_date]

    # Calculate changes
    new_water = (first_pred == 0) & (last_pred == 1)
    water_retreat = (first_pred == 1) & (last_pred == 0)
    persistent_water = (first_pred == 1) & (last_pred == 1)

    # Enlarge change areas (dilation)
    struct = np.ones((7, 7))
    new_water_dilated = binary_dilation(new_water, structure=struct, iterations=3)
    water_retreat_dilated = binary_dilation(water_retreat, structure=struct, iterations=3)

    # === Figure 1: Change detection (enlarged) ===
    change_map = np.ones((*first_pred.shape, 3)) * 0.95
    change_map[persistent_water] = [0.6, 0.8, 1.0]  # Light blue
    change_map[new_water_dilated] = [0.3, 0.5, 1.0]  # Medium blue (dilated)
    change_map[new_water] = [0, 0, 1]  # Deep blue (original)
    change_map[water_retreat_dilated] = [1, 0.6, 0.6]  # Light red (dilated)
    change_map[water_retreat] = [1, 0, 0]  # Deep red (original)

    fig, ax = plt.subplots(figsize=(14, 12))
    ax.imshow(change_map)
    new_count, retreat_count = new_water.sum(), water_retreat.sum()
    total = first_pred.size
    ax.set_title(f'Change Detection: {first_date} vs {last_date}\n'
                 f'New Water: {new_count:,} px ({new_count / total * 100:.2f}%) | '
                 f'Retreat: {retreat_count:,} px ({retreat_count / total * 100:.2f}%)', fontsize=13)
    ax.axis('off')
    legend_elements = [
        Patch(facecolor=[0, 0, 1], label='New Water'),
        Patch(facecolor=[1, 0, 0], label='Water Retreat'),
        Patch(facecolor=[0.6, 0.8, 1.0], label='Persistent Water'),
    ]
    ax.legend(handles=legend_elements, loc='lower right', fontsize=12)
    plt.savefig(os.path.join(out_dir, "pngs/analysis", "change_detection.png"), dpi=200, bbox_inches='tight')
    plt.close()
    print(f"  Saved: change_detection.png")

    # === Figure 2: Change only (black background) ===
    change_only = np.zeros((*first_pred.shape, 3))
    change_only[new_water_dilated] = [0, 0.5, 1]
    change_only[new_water] = [0, 1, 1]
    change_only[water_retreat_dilated] = [1, 0.5, 0]
    change_only[water_retreat] = [1, 1, 0]

    fig, ax = plt.subplots(figsize=(14, 12))
    ax.imshow(change_only)
    ax.set_title(f'Change Only (Cyan=New Water, Yellow=Retreat)\n{first_date} vs {last_date}', fontsize=13)
    ax.axis('off')
    plt.savefig(os.path.join(out_dir, "pngs/analysis", "change_only.png"), dpi=200, bbox_inches='tight')
    plt.close()
    print(f"  Saved: change_only.png")

    # === Figure 3: Time series comparison ===
    n_dates = len(dates)
    n_cols = min(5, n_dates)
    n_rows = (n_dates + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(4 * n_cols, 4 * n_rows))
    if n_rows == 1:
        axes = axes.reshape(1, -1)
    for idx, date in enumerate(dates):
        row, col = idx // n_cols, idx % n_cols
        ax = axes[row, col]
        ax.imshow(all_predictions[date], cmap='Blues', vmin=0, vmax=1)
        ax.set_title(f'{date}\n{all_predictions[date].mean() * 100:.1f}%', fontsize=10)
        ax.axis('off')
    for idx in range(n_dates, n_rows * n_cols):
        axes[idx // n_cols, idx % n_cols].axis('off')
    plt.suptitle('Flood Prediction Time Series', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "pngs/analysis", "temporal_series.png"), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: temporal_series.png")

    # === Figure 4: Water frequency map ===
    all_preds = np.stack([all_predictions[d] for d in dates], axis=0)
    water_freq = all_preds.mean(axis=0)
    fig, ax = plt.subplots(figsize=(12, 10))
    im = ax.imshow(water_freq, cmap='YlGnBu', vmin=0, vmax=1)
    ax.set_title(f'Water Frequency ({dates[0]}-{dates[-1]})\nHigher = More frequently flooded', fontsize=13)
    ax.axis('off')
    plt.colorbar(im, ax=ax, fraction=0.046, label='Frequency')
    plt.savefig(os.path.join(out_dir, "pngs/analysis", "water_frequency.png"), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: water_frequency.png")

    # === Figure 5: 824 comparison ===
    if '824' in all_predictions and '824' in ndwi_cache:
        pred_824 = all_predictions['824']
        gt_824 = (ndwi_cache['824'] > 0.1).astype(np.float32)
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))
        axes[0].imshow(gt_824, cmap='Blues')
        axes[0].set_title(f'GT 824\n{gt_824.mean():.2%}')
        axes[0].axis('off')
        axes[1].imshow(pred_824, cmap='Blues')
        axes[1].set_title(f'Pred 824\n{pred_824.mean():.2%}')
        axes[1].axis('off')
        diff = np.zeros((*gt_824.shape, 3))
        diff[..., 0] = (pred_824 == 1) & (gt_824 == 0)
        diff[..., 1] = (pred_824 == 1) & (gt_824 == 1)
        diff[..., 2] = (pred_824 == 0) & (gt_824 == 1)
        axes[2].imshow(diff)
        axes[2].set_title('Difference')
        axes[2].axis('off')
        plt.suptitle('824 Prediction vs Ground Truth', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "pngs/analysis", "824_comparison.png"), dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  Saved: 824_comparison.png")


def generate_metrics_plots(results_df, out_dir):
    """
    Generate metrics plots (saved separately)

    Figure 1: Water coverage over time - Shows predicted water area changes
    Figure 2: Rainfall bar chart - Shows daily rainfall
    Figure 3: Metrics over time - F1/IoU/SSIM changes (only dates with GT)
    Figure 4: Rainfall vs Water relationship - Explores correlation
    """
    dates = results_df['date'].values
    analysis_dir = os.path.join(out_dir, "pngs/analysis")

    # === Figure 1: Water coverage over time ===
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(dates, results_df['pred_water_%'], 'b-o', linewidth=2.5, markersize=10, label='Predicted Water')
    gt_data = results_df[results_df['has_gt'] == True]
    if len(gt_data) > 0:
        ax.plot(gt_data['date'], gt_data['gt_water_%'], 'g--s', linewidth=2, markersize=8, label='Ground Truth')
    ax.set_xlabel('Date', fontsize=12)
    ax.set_ylabel('Water Coverage (%)', fontsize=12)
    ax.set_title('Water Coverage Over Time\n(Blue=Predicted, Green=Ground Truth)', fontsize=14, fontweight='bold')
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    ax.tick_params(axis='x', rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(analysis_dir, "water_coverage_trend.png"), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: water_coverage_trend.png")

    # === Figure 2: Daily rainfall ===
    fig, ax = plt.subplots(figsize=(12, 6))
    colors = ['red' if r > 50 else 'orange' if r > 20 else 'skyblue' for r in results_df['rain_mm']]
    bars = ax.bar(dates, results_df['rain_mm'], color=colors, alpha=0.8, edgecolor='black')
    ax.set_xlabel('Date', fontsize=12)
    ax.set_ylabel('Rainfall (mm)', fontsize=12)
    ax.set_title('Daily Rainfall\n(Red>50mm, Orange>20mm, Blue<20mm)', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='y')
    ax.tick_params(axis='x', rotation=45)
    for bar, rain in zip(bars, results_df['rain_mm']):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5, f'{rain:.1f}',
                ha='center', va='bottom', fontsize=9)
    plt.tight_layout()
    plt.savefig(os.path.join(analysis_dir, "rainfall_daily.png"), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: rainfall_daily.png")

    # === Figure 3: Metrics over time ===
    gt_results = results_df[results_df['has_gt'] == True]
    if len(gt_results) > 0:
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(gt_results['date'], gt_results['f1'], 'b-o', linewidth=2.5, markersize=10, label='F1 Score')
        ax.plot(gt_results['date'], gt_results['iou'], 'r-s', linewidth=2, markersize=8, label='IoU')
        ax.plot(gt_results['date'], gt_results['ssim'], 'g-^', linewidth=2, markersize=8, label='SSIM')
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Score', fontsize=12)
        ax.set_title('Evaluation Metrics Over Time\n(Only dates with Ground Truth)', fontsize=14, fontweight='bold')
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        ax.set_ylim([0, 1])
        ax.tick_params(axis='x', rotation=45)
        plt.tight_layout()
        plt.savefig(os.path.join(analysis_dir, "metrics_over_time.png"), dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  Saved: metrics_over_time.png")

    # === Figure 4: Rainfall vs Water relationship ===
    fig, ax = plt.subplots(figsize=(10, 8))
    sc = ax.scatter(results_df['rain_mm'], results_df['pred_water_%'],
                    c=range(len(results_df)), cmap='viridis', s=150, alpha=0.8, edgecolors='black')
    for _, row in results_df.iterrows():
        ax.annotate(row['date'], (row['rain_mm'], row['pred_water_%']),
                    fontsize=10, ha='center', va='bottom', xytext=(0, 5), textcoords='offset points')
    ax.set_xlabel('Rainfall (mm)', fontsize=12)
    ax.set_ylabel('Predicted Water Coverage (%)', fontsize=12)
    ax.set_title('Rainfall vs Water Coverage\n(Color = Time sequence)', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    plt.colorbar(sc, ax=ax, label='Day sequence')
    plt.tight_layout()
    plt.savefig(os.path.join(analysis_dir, "rainfall_vs_water.png"), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: rainfall_vs_water.png")


def main():
    config = PredictConfig()

    print("=" * 70)
    print(f"Flood Prediction - Model: {config.MODEL_NAME}")
    print("=" * 70)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    setup_directories(config)
    model = load_model(config, device)
    rain_dict = load_rain_data(config)
    dem_full, profile = load_dem(config)
    ndwi_cache = load_all_ndwi(config)

    results = []
    predictions_cache = {}
    all_predictions = {}

    for target_day in range(config.PREDICT_START, config.PREDICT_END + 1):
        target_date = str(target_day)
        print(f"\n{'=' * 50}")
        print(f"Target: {target_date}")

        input_dates = [str(target_day - config.SEQ_IN + i) for i in range(config.SEQ_IN)]
        print(f"Input: {' -> '.join(input_dates)}")

        ndwi_list = []
        for d in input_dates:
            if d in ndwi_cache:
                ndwi_list.append(ndwi_cache[d])
            elif d in predictions_cache:
                ndwi_list.append(predictions_cache[d])
                print(f"  Using predicted {d}")
            else:
                print(f"Missing {d}, skip")
                break
        else:
            ndwi_seq = np.stack(ndwi_list, axis=0)
            rain_past = np.mean([rain_dict.get(d, 0.0) for d in input_dates])
            rain_future = rain_dict.get(target_date, 0.0)
            threshold = select_threshold(rain_future, config)

            pred_prob = predict_full_image(model, ndwi_seq, rain_past, rain_future, dem_full, device, config.PATCH_SIZE)
            pred_binary = (pred_prob > threshold).astype(np.float32)
            pred_processed = apply_postprocessing(pred_binary, config)

            predictions_cache[target_date] = pred_processed * 1.0 - 0.5
            all_predictions[target_date] = pred_processed.copy()

            has_gt = target_date in ndwi_cache
            gt_ndwi = ndwi_cache.get(target_date, None)

            if has_gt:
                metrics = evaluate_prediction(pred_processed, pred_prob, gt_ndwi)
                print(f"F1={metrics['f1']:.4f}, IoU={metrics['iou']:.4f}, SSIM={metrics['ssim']:.4f}")
            else:
                metrics = {'accuracy': 0, 'precision': 0, 'recall': 0, 'f1': 0, 'iou': 0, 'kappa': 0,
                           'tp': 0, 'fp': 0, 'fn': 0, 'tn': 0, 'ssim': 0, 'rmse': 0, 'mae': 0,
                           'gt_water_ratio': 0, 'pred_water_ratio': pred_processed.mean()}
                print(f"No GT, Water: {pred_processed.mean():.2%}")

            # Save TIF
            with rasterio.open(os.path.join(config.OUT_DIR, "tifs", f"{target_date}_pred.tif"), "w", **profile) as dst:
                dst.write(pred_processed.astype(np.float32), 1)

            save_separate_figures(pred_prob, pred_processed, gt_ndwi, metrics, target_date, config.OUT_DIR, has_gt)

            results.append({
                'date': target_date, 'has_gt': has_gt, 'rain_mm': rain_future, 'threshold': threshold,
                'f1': metrics['f1'], 'iou': metrics['iou'], 'precision': metrics['precision'],
                'recall': metrics['recall'], 'accuracy': metrics['accuracy'], 'kappa': metrics.get('kappa', 0),
                'ssim': metrics.get('ssim', 0), 'rmse': metrics.get('rmse', 0), 'mae': metrics.get('mae', 0),
                'gt_water_%': metrics['gt_water_ratio'] * 100, 'pred_water_%': metrics['pred_water_ratio'] * 100
            })

    # Summary
    if results:
        results_df = pd.DataFrame(results)
        results_df.to_csv(os.path.join(config.OUT_DIR, "evaluation_results.csv"), index=False)

        print(f"\n{'=' * 70}")
        print("SUMMARY")
        print("=" * 70)

        gt_results = results_df[results_df['has_gt'] == True]
        if len(gt_results) > 0:
            print(f"\n[Classification Metrics]")
            print(f"   F1:          {gt_results['f1'].mean():.4f}")
            print(f"   IoU:         {gt_results['iou'].mean():.4f}")
            print(f"   Precision:   {gt_results['precision'].mean():.4f}")
            print(f"   Recall:      {gt_results['recall'].mean():.4f}")
            print(f"   Kappa:       {gt_results['kappa'].mean():.4f}")

            print(f"\n[Image Similarity Metrics]")
            print(f"   SSIM:        {gt_results['ssim'].mean():.4f}")
            print(f"   RMSE:        {gt_results['rmse'].mean():.4f}")
            print(f"   MAE:         {gt_results['mae'].mean():.4f}")

        generate_change_detection(all_predictions, ndwi_cache, config.OUT_DIR)
        generate_metrics_plots(results_df, config.OUT_DIR)

    print(f"\n{'=' * 70}")
    print(f"Done! Output: {config.OUT_DIR}")
    print("=" * 70)


if __name__ == "__main__":
    main()
