﻿import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split, Dataset
from tqdm import tqdm
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import warnings
import json

warnings.filterwarnings('ignore')
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 150

from models import get_model, ABLATION_MODELS, count_parameters

try:
    from dataset_corrected_fixed import FloodDataset
    print("使用 dataset_corrected_fixed")
except ImportError:
    try:
        from dataset_corrected import FloodDataset
        print("使用 dataset_corrected")
    except ImportError:
        from dataset import FloodDataset
        print("使用 dataset")


class AugmentedDataset(Dataset):
    def __init__(self, base_dataset, augment_factor=4):
        self.base_dataset = base_dataset
        self.augment_factor = augment_factor
        self.augmentations = ['original', 'hflip', 'vflip', 'rot90', 'rot180', 'rot270']

    def __len__(self):
        return len(self.base_dataset) * self.augment_factor

    def __getitem__(self, idx):
        base_idx = idx // self.augment_factor
        aug_idx = idx % self.augment_factor
        sample = self.base_dataset[base_idx]
        ndwi_input = sample['ndwi_input']
        ndwi_label = sample['ndwi_label']
        dem = sample['dem']
        rain_target = sample['rain_target']

        aug_type = self.augmentations[aug_idx % len(self.augmentations)]
        if aug_type == 'hflip':
            ndwi_input = torch.flip(ndwi_input, [-1])
            ndwi_label = torch.flip(ndwi_label, [-1])
            dem = torch.flip(dem, [-1])
        elif aug_type == 'vflip':
            ndwi_input = torch.flip(ndwi_input, [-2])
            ndwi_label = torch.flip(ndwi_label, [-2])
            dem = torch.flip(dem, [-2])
        elif aug_type == 'rot90':
            ndwi_input = torch.rot90(ndwi_input, 1, [-2, -1])
            ndwi_label = torch.rot90(ndwi_label, 1, [-2, -1])
            dem = torch.rot90(dem, 1, [-2, -1])
        elif aug_type == 'rot180':
            ndwi_input = torch.rot90(ndwi_input, 2, [-2, -1])
            ndwi_label = torch.rot90(ndwi_label, 2, [-2, -1])
            dem = torch.rot90(dem, 2, [-2, -1])
        elif aug_type == 'rot270':
            ndwi_input = torch.rot90(ndwi_input, 3, [-2, -1])
            ndwi_label = torch.rot90(ndwi_label, 3, [-2, -1])
            dem = torch.rot90(dem, 3, [-2, -1])

        return {'ndwi_input': ndwi_input, 'ndwi_label': ndwi_label, 'dem': dem, 'rain_target': rain_target}


class Config:
    ROOT_DIR = r"\data"
    RAIN_CSV = r"\data\GPM\avg_precip_timeseries.csv"
    DEM_PATH = r"\data\dem\DEM.tif"
    SAVE_PATH = r"\results"

    BATCH_SIZE = 2
    EPOCHS = 10  # 快速验证
    LR = 1e-3
    WEIGHT_DECAY = 1e-4
    PATCH_SIZE = 256

    TRAIN_RATIO = 0.8
    AUGMENT_FACTOR = 4

    HIDDEN_DIM = 32
    RAIN_DIM = 16

    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    NUM_WORKERS = 0

    EARLY_STOP_PATIENCE = 10
    LR_PATIENCE = 5
    LR_FACTOR = 0.5
    MIN_LR = 1e-6

    FOCAL_ALPHA = 0.75
    FOCAL_GAMMA = 2.0


    MODELS_TO_TRAIN = [
        'convlstm_only',
        'convlstm_rain'
        'convlstm_dem',
        'convlstm_transformer',
        'full_model'
    ]


class FocalLoss(nn.Module):
    def __init__(self, alpha=0.75, gamma=2.0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.bce = nn.BCEWithLogitsLoss(reduction='none')

    def forward(self, pred, target):
        bce_loss = self.bce(pred, target)
        p_t = torch.sigmoid(pred) * target + (1 - torch.sigmoid(pred)) * (1 - target)
        focal_weight = (1 - p_t) ** self.gamma
        alpha_t = self.alpha * target + (1 - self.alpha) * (1 - target)
        return (alpha_t * focal_weight * bce_loss).mean()


class MetricTracker:
    def __init__(self):
        self.reset()

    def reset(self):
        self.tp = self.fp = self.fn = self.tn = 0
        self.loss_sum = 0.0
        self.count = 0

    def update(self, pred, target, loss):
        with torch.no_grad():
            pred_binary = (torch.sigmoid(pred) > 0.5).float()
            self.tp += ((pred_binary == 1) & (target == 1)).sum().item()
            self.fp += ((pred_binary == 1) & (target == 0)).sum().item()
            self.fn += ((pred_binary == 0) & (target == 1)).sum().item()
            self.tn += ((pred_binary == 0) & (target == 0)).sum().item()
            self.loss_sum += loss
            self.count += 1

    def compute(self):
        eps = 1e-7
        precision = self.tp / max(self.tp + self.fp, eps)
        recall = self.tp / max(self.tp + self.fn, eps)
        f1 = 2 * precision * recall / max(precision + recall, eps)
        total = self.tp + self.fp + self.fn + self.tn
        return {
            'loss': self.loss_sum / max(self.count, 1),
            'accuracy': (self.tp + self.tn) / max(total, 1),
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'iou': self.tp / max(self.tp + self.fp + self.fn, eps)
        }


def prepare_rain_data(batch, device):
    rain_target = batch["rain_target"].to(device)
    if "rain_past" in batch and "rain_future" in batch:
        return batch["rain_past"].to(device), batch["rain_future"].to(device)
    if rain_target.dim() == 1:
        rain_target = rain_target.unsqueeze(1)
    n_steps = rain_target.shape[1]
    if n_steps > 1:
        mid = n_steps // 2
        rain_past = rain_target[:, :mid].mean(dim=1, keepdim=True)
        rain_future = rain_target[:, mid:].mean(dim=1, keepdim=True)
    else:
        rain_past = rain_target
        rain_future = rain_target
    return rain_past, rain_future


def train_one_epoch(model, dataloader, criterion, optimizer, device, epoch, total_epochs):
    model.train()
    tracker = MetricTracker()
    pbar = tqdm(dataloader, desc=f"Epoch {epoch+1}/{total_epochs} [Train]")
    for batch in pbar:
        try:
            ndwi_input = batch["ndwi_input"].to(device)
            dem = batch["dem"].to(device)
            ndwi_label = batch["ndwi_label"].to(device)
            rain_past, rain_future = prepare_rain_data(batch, device)
            output = model(ndwi_input, rain_past, rain_future, dem)
            loss = criterion(output, ndwi_label)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            tracker.update(output, ndwi_label, loss.item())
            pbar.set_postfix({'loss': f"{loss.item():.4f}"})
        except Exception as e:
            print(f"\n错误: {e}")
            continue
    return tracker.compute()


@torch.no_grad()
def validate(model, dataloader, criterion, device):
    model.eval()
    tracker = MetricTracker()
    for batch in dataloader:
        try:
            ndwi_input = batch["ndwi_input"].to(device)
            dem = batch["dem"].to(device)
            ndwi_label = batch["ndwi_label"].to(device)
            rain_past, rain_future = prepare_rain_data(batch, device)
            output = model(ndwi_input, rain_past, rain_future, dem)
            loss = criterion(output, ndwi_label)
            tracker.update(output, ndwi_label, loss.item())
        except:
            continue
    return tracker.compute()


def train_model(model_name, train_loader, val_loader, config):
    print(f"\n{'='*60}")
    print(f"训练模型: {model_name}")
    print(f"{'='*60}")

    model_save_dir = os.path.join(config.SAVE_PATH, model_name)
    os.makedirs(model_save_dir, exist_ok=True)

    model = get_model(model_name, input_channels=1, hidden_dim=config.HIDDEN_DIM,
                      patch_size=config.PATCH_SIZE, dem_channels=1, rain_dim=config.RAIN_DIM).to(config.DEVICE)

    total_params = count_parameters(model)
    print(f"参数量: {total_params:,}")

    optimizer = optim.AdamW(model.parameters(), lr=config.LR, weight_decay=config.WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', patience=config.LR_PATIENCE,
                                                      factor=config.LR_FACTOR, min_lr=config.MIN_LR)
    criterion = FocalLoss(alpha=config.FOCAL_ALPHA, gamma=config.FOCAL_GAMMA)

    history = {'train_loss': [], 'train_f1': [], 'val_loss': [], 'val_f1': [], 'lr': []}
    best_f1 = 0
    best_epoch = 0

    for epoch in range(config.EPOCHS):
        train_metrics = train_one_epoch(model, train_loader, criterion, optimizer, config.DEVICE, epoch, config.EPOCHS)
        val_metrics = validate(model, val_loader, criterion, config.DEVICE)
        current_lr = optimizer.param_groups[0]['lr']

        history['train_loss'].append(train_metrics['loss'])
        history['train_f1'].append(train_metrics['f1'])
        history['val_loss'].append(val_metrics['loss'])
        history['val_f1'].append(val_metrics['f1'])
        history['lr'].append(current_lr)

        scheduler.step(val_metrics['f1'])
        print(f"\nEpoch {epoch+1}: Train F1={train_metrics['f1']:.4f}, Val F1={val_metrics['f1']:.4f}")

        if val_metrics['f1'] > best_f1:
            best_f1 = val_metrics['f1']
            best_epoch = epoch
            torch.save({'epoch': epoch, 'model_state_dict': model.state_dict(), 'metrics': val_metrics},
                       os.path.join(model_save_dir, 'best_model.pth'))
            print(f"  ★ 新最佳! F1={best_f1:.4f}")

    pd.DataFrame(history).to_csv(os.path.join(model_save_dir, 'history.csv'), index=False)

    return {
        'model_name': model_name,
        'best_epoch': best_epoch + 1,
        'best_f1': best_f1,
        'final_train_f1': history['train_f1'][-1],
        'final_val_f1': history['val_f1'][-1],
        'total_params': total_params,
        'total_epochs': len(history['train_f1'])
    }


def main():
    print("="*70)
    print("洪水预测模型消融实验")
    print("="*70)
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    config = Config()
    print(f"设备: {config.DEVICE}")
    print(f"要训练的模型: {config.MODELS_TO_TRAIN}")

    os.makedirs(config.SAVE_PATH, exist_ok=True)

    print("\n加载数据集...")
    base_dataset = FloodDataset(
        root_dir=config.ROOT_DIR, rain_csv=config.RAIN_CSV, dem_path=config.DEM_PATH,
        patch_size=config.PATCH_SIZE, water_threshold_ndwi=0.1, min_water_ratio=0.01, sampling_strategy='all'
    )
    print(f"原始数据集: {len(base_dataset)}")

    train_size = int(len(base_dataset) * config.TRAIN_RATIO)
    val_size = len(base_dataset) - train_size
    train_base, val_base = random_split(base_dataset, [train_size, val_size],
                                         generator=torch.Generator().manual_seed(42))
    train_dataset = AugmentedDataset(train_base, augment_factor=config.AUGMENT_FACTOR)
    print(f"训练集（增强后）: {len(train_dataset)}, 验证集: {len(val_base)}")

    train_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=True,
                              num_workers=config.NUM_WORKERS, drop_last=True)
    val_loader = DataLoader(val_base, batch_size=config.BATCH_SIZE, shuffle=False,
                            num_workers=config.NUM_WORKERS)

    results = []
    for model_name in config.MODELS_TO_TRAIN:
        result = train_model(model_name, train_loader, val_loader, config)
        if result:
            results.append(result)
            print(f"\n✅ {model_name} 完成! F1={result['best_f1']:.4f}")

    if results:
        results_df = pd.DataFrame(results).sort_values('best_f1', ascending=False)
        results_df.to_csv(os.path.join(config.SAVE_PATH, 'results.csv'), index=False)

        print("\n" + "="*70)
        print("最终结果")
        print("="*70)
        print(results_df.to_string(index=False))

        print("\nðﾟﾓﾊ 过拟合分析:")
        for _, row in results_df.iterrows():
            gap = row['final_train_f1'] - row['final_val_f1']
            status = "✅" if gap < 0.1 else "⚠️" if gap < 0.15 else "ðﾟﾔﾴ"
            print(f"   {row['model_name']}: gap={gap:.4f} {status}")

        best = results_df.iloc[0]
        print(f"\nðﾟﾏﾆ 最佳模型: {best['model_name']} (F1={best['best_f1']:.4f})")

    print(f"\n结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == "__main__":
    main()
