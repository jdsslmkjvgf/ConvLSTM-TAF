# dataset_corrected_fixed.py - 修正版数据集，支持自定义DEM路径
import os
import numpy as np
import pandas as pd
from torch.utils.data import Dataset
import torch
from PIL import Image
import random
import glob


class FloodDataset(Dataset):
    def __init__(self, root_dir, rain_csv,
                 dem_path=None,  # 新增：自定义DEM路径
                 patch_size=256,
                 water_threshold_ndwi=0.1,
                 min_water_ratio=0.05,
                 sampling_strategy='balanced'):
        """
        洪水预测数据集 - 适配实际文件格式

        参数:
            root_dir: 根目录
            rain_csv: 降雨CSV路径
            dem_path: DEM文件路径（可选，如果为None则自动查找）
            patch_size: patch大小
            water_threshold_ndwi: NDWI水体判定阈值
            min_water_ratio: 最小水体比例
            sampling_strategy: 采样策略 ('all', 'balanced', 'water_only')
        """
        self.root_dir = root_dir
        self.patch_size = patch_size
        self.water_threshold_ndwi = water_threshold_ndwi
        self.min_water_ratio = min_water_ratio
        self.sampling_strategy = sampling_strategy
        self.dem_path = dem_path  # 保存DEM路径

        print("=" * 60)
        print("初始化洪水预测数据集")
        print(f"根目录: {root_dir}")
        print(f"水体判定阈值: NDWI > {water_threshold_ndwi}")
        print(f"Patch最小水体比例: {min_water_ratio * 100:.1f}%")
        print(f"采样策略: {sampling_strategy}")
        print("=" * 60)

        # 加载数据
        self.ndwi_paths, self.ndwi_dates = self._load_ndwi_paths()
        self.dem = self._load_dem()
        self.rain_data = self._load_rain_data(rain_csv)

        # 分析数据特征
        if len(self.ndwi_paths) > 0:
            self._analyze_data_characteristics()

        # 生成训练样本
        self.samples = self._generate_samples()

        if len(self.samples) == 0:
            print("⚠️ 警告：没有生成任何样本，创建默认样本...")
            self.samples = self._create_default_samples()

        print(f"\n✅ 数据集准备完成！")
        print(f"   总样本数: {len(self.samples)}")

    def _load_ndwi_paths(self):
        """加载NDWI图像路径"""
        ndwi_dir = os.path.join(self.root_dir, "images")
        print(f"\n📁 扫描NDWI图像目录: {ndwi_dir}")

        if not os.path.exists(ndwi_dir):
            raise FileNotFoundError(f"NDWI目录不存在: {ndwi_dir}")

        # 查找所有.tif文件
        tif_files = glob.glob(os.path.join(ndwi_dir, "*.tif"))
        tif_files.extend(glob.glob(os.path.join(ndwi_dir, "*.TIF")))

        # 去重并排序
        tif_files = list(set(tif_files))

        paths = []
        dates = []

        for filepath in tif_files:
            filename = os.path.basename(filepath)
            name_without_ext = os.path.splitext(filename)[0]

            # 尝试直接转换为数字
            try:
                date = int(name_without_ext)
                paths.append(filepath)
                dates.append(date)
                continue
            except ValueError:
                pass

            # 尝试提取文件名中的数字
            import re
            numbers = re.findall(r'\d+', name_without_ext)
            if numbers:
                date = int(numbers[0])
                if 100 <= date <= 9999:
                    paths.append(filepath)
                    dates.append(date)

        # 按日期排序
        if paths:
            sorted_pairs = sorted(zip(dates, paths))
            dates, paths = zip(*sorted_pairs)
            dates = list(dates)
            paths = list(paths)

        print(f"   找到 {len(paths)} 个NDWI文件")
        if len(paths) > 0:
            print(f"   日期范围: {min(dates)} - {max(dates)}")
            print(f"   文件列表:")
            for i, (date, path) in enumerate(zip(dates[:6], paths[:6])):
                print(f"     {date}: {os.path.basename(path)}")
            if len(paths) > 6:
                print(f"     ... 还有 {len(paths) - 6} 个文件")

        return paths, dates

    def _load_dem(self):
        """加载DEM数据 - 支持多种路径"""
        print(f"\n📁 加载DEM数据...")

        # 尝试的路径列表
        possible_paths = []

        # 1. 如果提供了自定义路径
        if self.dem_path and os.path.exists(self.dem_path):
            possible_paths.append(self.dem_path)

        # 2. 原始位置
        possible_paths.append(os.path.join(self.root_dir, "DEM", "dem.tif"))

        # 3. 根目录直接包含
        possible_paths.append(os.path.join(self.root_dir, "dem.tif"))

        # 4. 在DEM文件夹的各种可能名称
        for name in ["dem.tif", "DEM.tif", "dem.TIF", "DEM.TIF"]:
            possible_paths.append(os.path.join(self.root_dir, "DEM", name))
            possible_paths.append(os.path.join(self.root_dir, name))

        # 尝试加载
        for dem_path in possible_paths:
            if os.path.exists(dem_path):
                try:
                    print(f"   尝试加载: {dem_path}")
                    dem = Image.open(dem_path)
                    dem_array = np.array(dem, dtype=np.float32)

                    if len(dem_array.shape) == 3:
                        dem_array = dem_array[:, :, 0]

                    # 标准化
                    dem_mean = dem_array.mean()
                    dem_std = dem_array.std()
                    if dem_std > 0:
                        dem_array = (dem_array - dem_mean) / dem_std

                    dem_array = dem_array[np.newaxis, :, :]

                    print(f"✅ DEM加载成功: {dem_array.shape}")
                    print(f"   范围: [{np.min(dem_array):.3f}, {np.max(dem_array):.3f}]")
                    return dem_array

                except Exception as e:
                    print(f"   加载失败: {e}")
                    continue

        # 如果都失败了，使用默认值
        print(f"⚠️ 所有DEM路径都不存在，使用零值默认DEM")
        print(f"   尝试过的路径:")
        for p in possible_paths[:5]:
            print(f"     - {p}")
        return np.zeros((1, 1024, 1024), dtype=np.float32)

    def _load_rain_data(self, csv_path):
        """加载降雨数据"""
        print(f"\n📁 加载降雨数据: {csv_path}")
        rain_data = {}

        if not os.path.exists(csv_path):
            print(f"⚠️ 降雨数据不存在，使用模拟数据")
            for date in self.ndwi_dates:
                rain_data[date] = np.random.uniform(5, 50)
            return rain_data

        try:
            df = pd.read_csv(csv_path)
            print(f"   降雨数据列: {list(df.columns)}")

            # 查找日期列
            date_col = None
            for col in df.columns:
                if 'date' in col.lower():
                    date_col = col
                    break
            if not date_col and 'Date' in df.columns:
                date_col = 'Date'

            # 查找降雨列
            rain_col = None
            for col in df.columns:
                if 'precip' in col.lower() or 'rain' in col.lower():
                    rain_col = col
                    break
            if not rain_col and 'Avg_Precip_mm_per_day' in df.columns:
                rain_col = 'Avg_Precip_mm_per_day'

            if date_col and rain_col:
                for _, row in df.iterrows():
                    try:
                        date = int(row[date_col])
                        rain = float(row[rain_col])
                        rain_data[date] = rain
                    except (ValueError, KeyError) as e:
                        continue

                print(f"✅ 降雨数据加载成功: {len(rain_data)} 条记录")

                if len(rain_data) > 0:
                    dates_sorted = sorted(rain_data.keys())[:5]
                    print(f"   前几条降雨数据:")
                    for d in dates_sorted:
                        print(f"     日期 {d}: {rain_data[d]:.2f} mm/day")
            else:
                print(f"⚠️ 无法识别CSV列名，使用模拟数据")
                print(f"   找到的列: {list(df.columns)}")
                for date in self.ndwi_dates:
                    rain_data[date] = np.random.uniform(5, 50)

        except Exception as e:
            print(f"⚠️ 降雨数据加载失败: {e}")
            for date in self.ndwi_dates:
                rain_data[date] = np.random.uniform(5, 50)

        return rain_data

    def _load_ndwi_image(self, path):
        """加载单个NDWI图像"""
        try:
            img = Image.open(path)
            img_array = np.array(img, dtype=np.float32)

            if len(img_array.shape) == 3:
                img_array = img_array[:, :, 0]

            # 对于NDWI，保持原始值范围[-1, 1]
            if img_array.min() < -1.5 or img_array.max() > 1.5:
                img_array = 2 * (img_array - img_array.min()) / (img_array.max() - img_array.min() + 1e-8) - 1

            return img_array

        except Exception as e:
            print(f"⚠️ 加载图像失败 {path}: {e}")
            return np.zeros((1024, 1024), dtype=np.float32)

    def _analyze_data_characteristics(self):
        """分析数据特征"""
        if len(self.ndwi_paths) == 0:
            return

        print("\n📊 分析NDWI数据特征...")

        sample_img = self._load_ndwi_image(self.ndwi_paths[0])

        stats = {
            'min': np.min(sample_img),
            'max': np.max(sample_img),
            'mean': np.mean(sample_img),
            'std': np.std(sample_img),
            'median': np.median(sample_img),
            'water_pixels': np.sum(sample_img > self.water_threshold_ndwi),
            'total_pixels': sample_img.size,
            'water_ratio': np.mean(sample_img > self.water_threshold_ndwi) * 100
        }

        print(f"   NDWI范围: [{stats['min']:.3f}, {stats['max']:.3f}]")
        print(f"   NDWI均值: {stats['mean']:.3f} (标准差: {stats['std']:.3f})")
        print(f"   水体像素 (>{self.water_threshold_ndwi}): {stats['water_pixels']:,} / {stats['total_pixels']:,}")
        print(f"   水体覆盖率: {stats['water_ratio']:.2f}%")

    def _generate_samples(self):
        """生成训练样本"""
        samples = []

        if len(self.ndwi_paths) < 6:
            print(f"⚠️ 图像数量不足 (需要≥6，实际{len(self.ndwi_paths)})")
            if len(self.ndwi_paths) >= 2:
                return self._create_samples_with_limited_data()
            else:
                return []

        print("\n🔍 生成训练样本...")

        num_sequences = len(self.ndwi_paths) - 5
        total_samples = 0

        for seq_idx in range(num_sequences):
            target_date = self.ndwi_dates[seq_idx + 5]

            if target_date not in self.rain_data:
                print(f"   ⚠️ 日期 {target_date} 没有降雨数据，使用默认值")
                self.rain_data[target_date] = 25.0

            last_frame = self._load_ndwi_image(self.ndwi_paths[seq_idx + 4])
            h, w = last_frame.shape

            stride = self.patch_size // 2

            patches_this_seq = 0
            for y in range(0, h - self.patch_size + 1, stride):
                for x in range(0, w - self.patch_size + 1, stride):
                    patch = last_frame[y:y + self.patch_size, x:x + self.patch_size]
                    water_ratio = np.mean(patch > self.water_threshold_ndwi)

                    use_patch = False
                    if self.sampling_strategy == 'all':
                        use_patch = True
                    elif self.sampling_strategy == 'balanced':
                        if water_ratio > self.min_water_ratio:
                            use_patch = True
                        else:
                            use_patch = random.random() < 0.3
                    else:
                        use_patch = water_ratio > self.min_water_ratio

                    if use_patch:
                        samples.append({
                            'input_indices': list(range(seq_idx, seq_idx + 5)),
                            'target_index': seq_idx + 5,
                            'patch_coords': (y, x, y + self.patch_size, x + self.patch_size),
                            'water_ratio': water_ratio,
                            'patch_type': 'water' if water_ratio > 0.5 else (
                                'mixed' if water_ratio > self.min_water_ratio else 'land')
                        })
                        patches_this_seq += 1

            total_samples += patches_this_seq
            if seq_idx < 3 or seq_idx == num_sequences - 1:
                print(f"   序列 {seq_idx + 1}: 生成 {patches_this_seq} 个patches")

        print(f"   总计生成 {len(samples)} 个训练样本")

        if len(samples) < 50 and len(samples) > 0:
            print(f"   样本较少，通过数据增强扩充...")
            samples = self._augment_samples(samples)

        return samples

    def _create_samples_with_limited_data(self):
        """用有限的数据创建样本"""
        samples = []
        num_images = len(self.ndwi_paths)

        print(f"   使用 {num_images} 张图像创建样本（通过重复）")

        for y in range(0, 1024 - self.patch_size + 1, self.patch_size // 2):
            for x in range(0, 1024 - self.patch_size + 1, self.patch_size // 2):
                if num_images >= 2:
                    input_indices = [num_images - 2] * 4 + [num_images - 1]
                    target_index = num_images - 1
                else:
                    input_indices = [0] * 5
                    target_index = 0

                samples.append({
                    'input_indices': input_indices,
                    'target_index': target_index,
                    'patch_coords': (y, x, y + self.patch_size, x + self.patch_size),
                    'water_ratio': 0.1,
                    'patch_type': 'mixed'
                })

        return samples

    def _augment_samples(self, samples):
        """数据增强"""
        augmented = list(samples)

        for sample in samples[:min(20, len(samples))]:
            y1, x1, y2, x2 = sample['patch_coords']

            for _ in range(2):
                offset_y = random.randint(-32, 32)
                offset_x = random.randint(-32, 32)

                new_y1 = max(0, min(y1 + offset_y, 1024 - self.patch_size))
                new_x1 = max(0, min(x1 + offset_x, 1024 - self.patch_size))

                augmented.append({
                    'input_indices': sample['input_indices'],
                    'target_index': sample['target_index'],
                    'patch_coords': (new_y1, new_x1, new_y1 + self.patch_size, new_x1 + self.patch_size),
                    'water_ratio': sample['water_ratio'],
                    'patch_type': sample['patch_type']
                })

        print(f"   数据增强: {len(samples)} → {len(augmented)} 个样本")
        return augmented

    def _create_default_samples(self):
        """创建默认样本"""
        print("   创建默认样本...")
        samples = []
        for i in range(10):
            samples.append({
                'input_indices': [0] * 5 if len(self.ndwi_paths) > 0 else [0] * 5,
                'target_index': 0,
                'patch_coords': (0, 0, self.patch_size, self.patch_size),
                'water_ratio': 0.1,
                'patch_type': 'default'
            })
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        """获取一个训练样本"""
        sample_info = self.samples[idx]
        y1, x1, y2, x2 = sample_info['patch_coords']

        # 加载输入序列（5帧）
        input_frames = []
        for i in sample_info['input_indices']:
            if i < len(self.ndwi_paths):
                frame = self._load_ndwi_image(self.ndwi_paths[i])
            else:
                frame = np.zeros((1024, 1024), dtype=np.float32)

            patch = frame[y1:y2, x1:x2]

            if patch.shape != (self.patch_size, self.patch_size):
                resized = np.zeros((self.patch_size, self.patch_size), dtype=np.float32)
                h, w = patch.shape
                resized[:min(h, self.patch_size), :min(w, self.patch_size)] = \
                    patch[:min(h, self.patch_size), :min(w, self.patch_size)]
                patch = resized

            input_frames.append(patch[np.newaxis, :, :])

        # 加载目标帧
        target_idx = sample_info['target_index']
        if target_idx < len(self.ndwi_paths):
            target_frame = self._load_ndwi_image(self.ndwi_paths[target_idx])
        else:
            target_frame = np.zeros((1024, 1024), dtype=np.float32)

        target_patch = target_frame[y1:y2, x1:x2]

        if target_patch.shape != (self.patch_size, self.patch_size):
            resized = np.zeros((self.patch_size, self.patch_size), dtype=np.float32)
            h, w = target_patch.shape
            resized[:min(h, self.patch_size), :min(w, self.patch_size)] = \
                target_patch[:min(h, self.patch_size), :min(w, self.patch_size)]
            target_patch = resized

        # 二分类标签
        target_binary = (target_patch > self.water_threshold_ndwi).astype(np.float32)

        # 获取降雨数据
        if target_idx < len(self.ndwi_dates):
            target_date = self.ndwi_dates[target_idx]
            rain_value = self.rain_data.get(target_date, 25.0)
        else:
            rain_value = 25.0

        # 提取DEM patch
        dem_patch = self.dem[:, y1:y2, x1:x2]
        if dem_patch.shape != (1, self.patch_size, self.patch_size):
            resized = np.zeros((1, self.patch_size, self.patch_size), dtype=np.float32)
            c, h, w = dem_patch.shape
            resized[:, :min(h, self.patch_size), :min(w, self.patch_size)] = \
                dem_patch[:, :min(h, self.patch_size), :min(w, self.patch_size)]
            dem_patch = resized

        return {
            'ndwi_input': torch.from_numpy(np.stack(input_frames, axis=0)).float(),
            'rain_target': torch.tensor([rain_value], dtype=torch.float32),
            'dem': torch.from_numpy(dem_patch).float(),
            'ndwi_label': torch.from_numpy(target_binary[np.newaxis, :, :]).float(),
            'patch_type': sample_info['patch_type'],
            'water_ratio': sample_info['water_ratio']
        }


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("测试数据集加载")
    print("=" * 60)

    # 测试1: 使用默认DEM路径
    print("\n测试1: 默认DEM路径")
    dataset = FloodDataset(
        root_dir=r"E:\10.13\data",
        rain_csv=r"E:\10.13\data\GPM\avg_precip_timeseries.csv",
        patch_size=256,
        water_threshold_ndwi=0.1,
        min_water_ratio=0.05,
        sampling_strategy='balanced'
    )

    # 测试2: 指定DEM路径
    print("\n\n测试2: 指定DEM路径")
    dataset2 = FloodDataset(
        root_dir=r"E:\10.13\data",
        rain_csv=r"E:\10.13\data\GPM\avg_precip_timeseries.csv",
        dem_path=r"E:\10.13\data\dem.tif",  # 自定义路径
        patch_size=256,
        water_threshold_ndwi=0.1,
        min_water_ratio=0.05,
        sampling_strategy='balanced'
    )

    print(f"\n最终数据集大小: {len(dataset)}")

    if len(dataset) > 0:
        sample = dataset[0]
        print(f"\n第一个样本信息:")
        for key, value in sample.items():
            if isinstance(value, torch.Tensor):
                print(f"  {key}: shape={value.shape}, dtype={value.dtype}")
            else:
                print(f"  {key}: {value}")