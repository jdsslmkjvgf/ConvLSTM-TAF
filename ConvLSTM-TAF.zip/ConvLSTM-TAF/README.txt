# Flood Prediction Ablation Study

A deep learning framework for flood prediction using ConvLSTM-based architectures with ablation experiments to evaluate the contribution of different components.

## Overview

This project implements multiple neural network architectures for flood inundation prediction, combining:
- **ConvLSTM** for spatiotemporal sequence modeling
- **Spatial Attention** for focusing on relevant regions
- **DEM (Digital Elevation Model)** for terrain information
- **Rainfall data** for meteorological context

The ablation study systematically evaluates each component's contribution to prediction performance.

## Model Architectures

| Model | Description | Key Components |
|-------|-------------|----------------|
| `convlstm_only` | Baseline model | ConvLSTM only |
| `transformer_only` | Attention-based | Channel + Spatial Attention |
| `convlstm_dem` | With terrain | ConvLSTM + DEM features |
| `convlstm_rain` | With precipitation | ConvLSTM + Rainfall encoding |
| `convlstm_transformer` | With spatial attention | ConvLSTM + Spatial Attention |
| `full_model` | Complete architecture | All components combined |
| `simplified` | Lightweight version | Reduced complexity full model |

### Architecture Diagram

```
Input Sequence (B, T, C, H, W)
         │
         ▼
    ┌─────────────┐
    │  ConvLSTM   │  ← Spatiotemporal feature extraction
    │  (2 layers) │
    └─────────────┘
         │
         ▼
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │ LSTM Feat   │  +  │  DEM Feat   │  +  │ Rain Feat   │
    │ (H, W)      │     │ (H, W)      │     │ (broadcast) │
    └─────────────┘     └─────────────┘     └─────────────┘
         │                    │                   │
         └────────────────────┴───────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ Spatial Attention│
                    └─────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │  Conv Decoder   │
                    └─────────────────┘
                              │
                              ▼
                    Output (B, 1, H, W)
```

## Requirements

```
torch>=1.9.0
numpy>=1.19.0
pandas>=1.3.0
matplotlib>=3.4.0
tqdm>=4.60.0
rasterio  # for DEM/GeoTIFF processing
```

## Project Structure

```
project/
├── ablation_models_v2.py         # Model definitions
├── ablation_experiment_50epochs.py  # Training script
├── dataset_corrected_fixed.py    # Dataset loader (required)
├── data/
│   ├── GPM/
│   │   └── avg_precip_timeseries.csv
│   ├── dem/
│   │   └── DEM.tif
│   └── [NDWI images...]
└── results_50epochs/             # Output directory
    ├── convlstm_only/
    │   ├── best_model.pth
    │   ├── training_history.csv
    │   └── training_curves.png
    ├── full_model/
    │   └── ...
    └── ablation_summary_50epochs.csv
```

## Usage

### Quick Start

```python
from ablation_models_v2 import get_model, ABLATION_MODELS

# List available models
print(ABLATION_MODELS.keys())

# Initialize a model
model = get_model('full_model', 
                  input_channels=1,
                  hidden_dim=32,
                  dem_channels=1,
                  patch_size=256,
                  transformer_dim=64,
                  rain_dim=16)

# Forward pass
output = model(x_seq, rain_past, rain_future, dem)
# x_seq: (B, T, C, H, W) - NDWI sequence
# rain_past: (B, T_past) - Historical rainfall
# rain_future: (B, T_future) - Forecast rainfall  
# dem: (B, 1, H, W) - Digital elevation model
# output: (B, 1, H, W) - Flood prediction logits
```

### Run Ablation Experiment

```bash
python ablation_experiment_50epochs.py
```

### Configuration

Modify the `Config` class in `ablation_experiment_50epochs.py`:

```python
class Config:
    ROOT_DIR = "path/to/data"
    RAIN_CSV = "path/to/rainfall.csv"
    DEM_PATH = "path/to/DEM.tif"
    SAVE_PATH = "path/to/results"
    
    BATCH_SIZE = 2
    EPOCHS = 50
    LR = 1e-3
    PATCH_SIZE = 256
    
    EARLY_STOP_PATIENCE = 10
```

## Training Features

- **Focal Loss**: Handles class imbalance in flood/non-flood pixels
- **Learning Rate Scheduling**: ReduceLROnPlateau based on F1 score
- **Early Stopping**: Prevents overfitting (default: 10 epochs patience)
- **Gradient Clipping**: Stabilizes training (max_norm=1.0)
- **Automatic Checkpointing**: Saves best model based on F1 score

## Evaluation Metrics

| Metric | Description |
|--------|-------------|
| Accuracy | Overall pixel-wise accuracy |
| Precision | Flood pixels correctly identified / Total predicted flood |
| Recall | Flood pixels correctly identified / Total actual flood |
| F1 Score | Harmonic mean of Precision and Recall |

## Key Design Decisions

1. **Spatial Dimension Preservation**: All models maintain spatial dimensions throughout, avoiding information loss from flattening.

2. **ConvLSTM over Standard LSTM**: Captures spatial correlations in sequential data, essential for image-based flood prediction.

3. **Feature Broadcasting**: Scalar rainfall values are broadcast to spatial dimensions for seamless fusion with image features.

4. **Modular Architecture**: Easy to enable/disable components for ablation studies.

## Known Issues & Fixes Needed

1. **Import Path**: Update import statement in training script:
   ```python
   # Change from:
   from ablation_models import get_model
   # To:
   from ablation_models_v2 import get_model
   ```

2. **Rain Dimension Hardcoding**: The `Model_ConvLSTM_Rain` has hardcoded spatial projection for patch_size=256. For other sizes, modify:
   ```python
   self.rain_spatial = nn.Sequential(
       nn.Linear(rain_dim, (patch_size // 4) ** 2),  # Dynamic calculation
       nn.ReLU()
   )
   ```

## Expected Results

Typical F1 scores after 50 epochs training:

| Model | Expected F1 Range |
|-------|-------------------|
| convlstm_only | 0.65 - 0.75 |
| full_model | 0.75 - 0.85 |
| simplified | 0.70 - 0.80 |

*Results vary based on dataset and hyperparameters.*

## Citation

If you use this code, please cite:

```bibtex
@misc{flood_prediction_ablation,
  title={Flood Prediction with ConvLSTM-based Ablation Study},
  year={2024},
  note={Deep learning framework for flood inundation prediction}
}
```

## License

This dataset is released under the Creative Commons Attribution 4.0 International License (CC-BY 4.0). 
Users are free to share and adapt the data, provided appropriate credit is given.
