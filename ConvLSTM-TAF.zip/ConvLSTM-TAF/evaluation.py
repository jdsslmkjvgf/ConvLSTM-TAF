import os
import numpy as np
import rasterio
import matplotlib.pyplot as plt
import pandas as pd
from scipy.ndimage import uniform_filter

plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 150


# ===== ���� =====
class Config:
    # Ԥ����Ŀ¼
    PRED_DIR = r"\results"

    # GTĿ¼��NDWIͼ��
    GT_DIR = r"\data\images"

    # ���Ŀ¼
    OUT_DIR = r"\evaluation"

    # ģ�����ƣ�����ͼ�����⣩
    MODEL_NAME = "model_name"

    # ˮ����ֵ
    WATER_THRESHOLD = 0.1


# ===== ����ָ����� =====
def calculate_ssim(img1, img2):
    """����SSIM"""
    C1, C2 = 0.01 ** 2, 0.03 ** 2
    img1, img2 = img1.astype(np.float64), img2.astype(np.float64)
    mu1, mu2 = uniform_filter(img1, size=11), uniform_filter(img2, size=11)
    sigma1_sq = uniform_filter(img1 ** 2, size=11) - mu1 ** 2
    sigma2_sq = uniform_filter(img2 ** 2, size=11) - mu2 ** 2
    sigma12 = uniform_filter(img1 * img2, size=11) - mu1 * mu2
    ssim_map = ((2 * mu1 * mu2 + C1) * (2 * sigma12 + C2)) / \
               ((mu1 ** 2 + mu2 ** 2 + C1) * (sigma1_sq + sigma2_sq + C2))
    return float(ssim_map.mean())


def calculate_auc(pred_prob, gt_binary):
    """����AUC"""
    pred_flat = pred_prob.flatten()
    gt_flat = gt_binary.flatten()
    sorted_indices = np.argsort(pred_flat)[::-1]
    gt_sorted = gt_flat[sorted_indices]

    n_pos, n_neg = gt_sorted.sum(), len(gt_sorted) - gt_sorted.sum()
    if n_pos == 0 or n_neg == 0:
        return 0.5

    auc, tp, fp = 0, 0, 0
    tpr_prev, fpr_prev = 0, 0

    for i in range(len(gt_sorted)):
        if gt_sorted[i] == 1:
            tp += 1
        else:
            fp += 1
        tpr, fpr = tp / n_pos, fp / n_neg
        auc += (fpr - fpr_prev) * (tpr + tpr_prev) / 2
        tpr_prev, fpr_prev = tpr, fpr

    return float(auc)


def evaluate(pred_binary, pred_prob, gt_binary):
    """������������ָ��"""
    eps = 1e-7

    # ��������
    tp = float(((pred_binary == 1) & (gt_binary == 1)).sum())
    fp = float(((pred_binary == 1) & (gt_binary == 0)).sum())
    fn = float(((pred_binary == 0) & (gt_binary == 1)).sum())
    tn = float(((pred_binary == 0) & (gt_binary == 0)).sum())

    # ����ָ��
    precision = tp / (tp + fp + eps)
    recall = tp / (tp + fn + eps)
    f1 = 2 * precision * recall / (precision + recall + eps)
    iou = tp / (tp + fp + fn + eps)
    accuracy = (tp + tn) / (tp + fp + fn + tn)

    # Kappa
    total = tp + fp + fn + tn
    po = (tp + tn) / total
    pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / (total ** 2)
    kappa = (po - pe) / (1.0 - pe + eps) if pe < 1.0 else 1.0

    # ͼ��ָ��
    ssim = calculate_ssim(pred_binary, gt_binary)
    rmse = np.sqrt(np.mean((pred_binary - gt_binary) ** 2))
    mae = np.mean(np.abs(pred_binary - gt_binary))

    # AUC
    auc = calculate_auc(pred_prob, gt_binary)

    return {
        'precision': precision, 'recall': recall, 'f1': f1,
        'iou': iou, 'accuracy': accuracy, 'kappa': kappa,
        'ssim': ssim, 'rmse': rmse, 'mae': mae, 'auc': auc,
        'tp': int(tp), 'fp': int(fp), 'fn': int(fn), 'tn': int(tn),
        'gt_water': gt_binary.mean() * 100,
        'pred_water': pred_binary.mean() * 100
    }


def load_tif(path):
    """��ȡTIF�ļ�"""
    with rasterio.open(path) as src:
        return src.read(1).astype(np.float32)


def main():
    config = Config()
    os.makedirs(config.OUT_DIR, exist_ok=True)

    print("=" * 60)
    print(f"Evaluation - {config.MODEL_NAME}")
    print("=" * 60)

    # �ҵ�����Ԥ���ļ�
    pred_files = [f for f in os.listdir(config.PRED_DIR) if f.endswith('_pred.tif')]
    dates = sorted([f.replace('_pred.tif', '') for f in pred_files])

    print(f"Found {len(dates)} predictions: {dates}")

    results = []

    for date in dates:
        pred_path = os.path.join(config.PRED_DIR, f"{date}_pred.tif")
        prob_path = os.path.join(config.PRED_DIR, f"{date}_prob.tif")
        gt_path = os.path.join(config.GT_DIR, f"{date}.tif")

        if not os.path.exists(gt_path):
            print(f"  {date}: No GT, skip")
            continue

        # ��ȡ����
        pred_binary = load_tif(pred_path)
        pred_prob = load_tif(prob_path) if os.path.exists(prob_path) else pred_binary
        gt_ndwi = load_tif(gt_path)
        gt_binary = (gt_ndwi > config.WATER_THRESHOLD).astype(np.float32)

        # ����
        metrics = evaluate(pred_binary, pred_prob, gt_binary)
        metrics['date'] = date
        results.append(metrics)

        print(f"  {date}: F1={metrics['f1']:.4f}, IoU={metrics['iou']:.4f}, AUC={metrics['auc']:.4f}")

    if not results:
        print("No results!")
        return

    # תΪDataFrame
    df = pd.DataFrame(results)
    df.to_csv(os.path.join(config.OUT_DIR, "metrics.csv"), index=False)

    # ===== ����ͼ�� =====

    # ͼ1: ָ����ܱ���ͼ
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.axis('off')

    mean_metrics = {
        'F1': df['f1'].mean(),
        'IoU': df['iou'].mean(),
        'Precision': df['precision'].mean(),
        'Recall': df['recall'].mean(),
        'Accuracy': df['accuracy'].mean(),
        'Kappa': df['kappa'].mean(),
        'AUC': df['auc'].mean(),
        'SSIM': df['ssim'].mean(),
        'RMSE': df['rmse'].mean(),
        'MAE': df['mae'].mean(),
    }

    table_text = f"""
    �X�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�[
    �U         {config.MODEL_NAME} - Evaluation Results         
    �d�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�g
    �U  [Classification Metrics]                        
    �U     F1 Score:     {mean_metrics['F1']:.4f}                      
    �U     IoU:          {mean_metrics['IoU']:.4f}                      
    �U     Precision:    {mean_metrics['Precision']:.4f}                      
    �U     Recall:       {mean_metrics['Recall']:.4f}                      
    �U     Accuracy:     {mean_metrics['Accuracy']:.4f}                      
    �U     Kappa:        {mean_metrics['Kappa']:.4f}                      
    �U     AUC:          {mean_metrics['AUC']:.4f}                      
    �d�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�g
    �U  [Image Similarity Metrics]                      
    �U     SSIM:         {mean_metrics['SSIM']:.4f}                      
    �U     RMSE:         {mean_metrics['RMSE']:.4f}                      
    �U     MAE:          {mean_metrics['MAE']:.4f}                      
    �^�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�a
    """

    ax.text(0.5, 0.5, table_text, fontsize=14, family='monospace',
            ha='center', va='center', transform=ax.transAxes,
            bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))

    plt.savefig(os.path.join(config.OUT_DIR, "metrics_summary.png"), dpi=200, bbox_inches='tight')
    plt.close()
    print(f"\nSaved: metrics_summary.png")

    # ͼ2: ��״ͼ�Ա�
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # ����ָ����״ͼ
    metrics_names = ['F1', 'IoU', 'Precision', 'Recall', 'Kappa', 'AUC']
    metrics_values = [mean_metrics[m] for m in metrics_names]
    colors = plt.cm.Blues(np.linspace(0.4, 0.8, len(metrics_names)))

    bars = axes[0].bar(metrics_names, metrics_values, color=colors, edgecolor='black')
    axes[0].set_ylim([0, 1])
    axes[0].set_ylabel('Score', fontsize=12)
    axes[0].set_title('Classification Metrics', fontsize=14, fontweight='bold')
    axes[0].grid(True, alpha=0.3, axis='y')
    for bar, val in zip(bars, metrics_values):
        axes[0].text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.02,
                     f'{val:.3f}', ha='center', fontsize=10)

    # ͼ��ָ����״ͼ
    img_names = ['SSIM', 'RMSE', 'MAE']
    img_values = [mean_metrics[m] for m in img_names]
    colors2 = ['green', 'orange', 'red']

    bars2 = axes[1].bar(img_names, img_values, color=colors2, alpha=0.7, edgecolor='black')
    axes[1].set_ylabel('Value', fontsize=12)
    axes[1].set_title('Image Similarity Metrics', fontsize=14, fontweight='bold')
    axes[1].grid(True, alpha=0.3, axis='y')
    for bar, val in zip(bars2, img_values):
        axes[1].text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                     f'{val:.4f}', ha='center', fontsize=10)

    plt.suptitle(f'{config.MODEL_NAME} Evaluation', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(config.OUT_DIR, "metrics_bars.png"), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"Saved: metrics_bars.png")

    # ͼ3: ÿ��ָ��仯
    if len(df) > 1:
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(df['date'], df['f1'], 'b-o', linewidth=2, markersize=8, label='F1')
        ax.plot(df['date'], df['iou'], 'r-s', linewidth=2, markersize=8, label='IoU')
        ax.plot(df['date'], df['auc'], 'g-^', linewidth=2, markersize=8, label='AUC')
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Score', fontsize=12)
        ax.set_title(f'{config.MODEL_NAME} - Metrics Over Time', fontsize=14, fontweight='bold')
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        ax.set_ylim([0, 1])
        ax.tick_params(axis='x', rotation=45)
        plt.tight_layout()
        plt.savefig(os.path.join(config.OUT_DIR, "metrics_timeline.png"), dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved: metrics_timeline.png")

    # ͼ4: �״�ͼ
    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(projection='polar'))

    categories = ['F1', 'IoU', 'Precision', 'Recall', 'Kappa', 'AUC', 'SSIM']
    values = [mean_metrics[c] for c in categories]
    values += values[:1]  # �պ�

    angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
    angles += angles[:1]

    ax.plot(angles, values, 'b-o', linewidth=2, markersize=8)
    ax.fill(angles, values, 'blue', alpha=0.25)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=11)
    ax.set_ylim([0, 1])
    ax.set_title(f'{config.MODEL_NAME} - Performance Radar', fontsize=14, fontweight='bold', pad=20)

    plt.tight_layout()
    plt.savefig(os.path.join(config.OUT_DIR, "metrics_radar.png"), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"Saved: metrics_radar.png")

    # ��ӡ����
    print(f"\n{'=' * 60}")
    print("SUMMARY")
    print("=" * 60)
    print(f"\n[Classification Metrics]")
    print(f"   F1:        {mean_metrics['F1']:.4f}")
    print(f"   IoU:       {mean_metrics['IoU']:.4f}")
    print(f"   Precision: {mean_metrics['Precision']:.4f}")
    print(f"   Recall:    {mean_metrics['Recall']:.4f}")
    print(f"   Accuracy:  {mean_metrics['Accuracy']:.4f}")
    print(f"   Kappa:     {mean_metrics['Kappa']:.4f}")
    print(f"   AUC:       {mean_metrics['AUC']:.4f}")
    print(f"\n[Image Similarity Metrics]")
    print(f"   SSIM:      {mean_metrics['SSIM']:.4f}")
    print(f"   RMSE:      {mean_metrics['RMSE']:.4f}")
    print(f"   MAE:       {mean_metrics['MAE']:.4f}")
    print(f"\nOutput: {config.OUT_DIR}")
    print("=" * 60)


if __name__ == "__main__":
    main()
